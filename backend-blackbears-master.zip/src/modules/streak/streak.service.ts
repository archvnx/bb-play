import { eq } from 'drizzle-orm';
import { STREAK_TIERS, getDiscountForStreak, getNextTier } from '../../config/streak.config.js';
import { db } from '../../db/client.js';
import { bookingStreaks } from '../../db/schema.js';
import { todayDateStr, yesterdayDateStr } from '../../utils/date.js';

export interface StreakInfo {
  currentStreak:    number;
  longestStreak:    number;
  discountPct:      number;
  nextTierDays:     number | null;
  nextTierDiscount: number | null;
  lastBookingDate:  string | null;
  tiers:            typeof STREAK_TIERS;
}

export async function getStreak(memberId: string): Promise<StreakInfo> {
  const rows = await db
    .select()
    .from(bookingStreaks)
    .where(eq(bookingStreaks.memberId, memberId))
    .limit(1);

  const row  = rows[0];
  const streak = row?.currentStreak ?? 0;
  const next   = getNextTier(streak);

  return {
    currentStreak:    streak,
    longestStreak:    row?.longestStreak  ?? 0,
    discountPct:      row?.discountPct    ?? 0,
    nextTierDays:     next?.days          ?? null,
    nextTierDiscount: next?.discount      ?? null,
    lastBookingDate:  row?.lastBookingDate ?? null,
    tiers: STREAK_TIERS,
  };
}

/** Вызывается после сохранения брони. Обновляет стрик и скидку. */
export async function updateStreak(memberId: string): Promise<void> {
  const today     = todayDateStr();
  const yesterday = yesterdayDateStr();

  const rows = await db
    .select()
    .from(bookingStreaks)
    .where(eq(bookingStreaks.memberId, memberId))
    .limit(1);

  const row = rows[0];

  // Уже обновляли сегодня
  if (row?.lastBookingDate === today) return;

  const prevDate = row?.lastBookingDate ?? null;
  const streak   = prevDate === yesterday ? (row!.currentStreak + 1) : 1;
  const longest  = Math.max(streak, row?.longestStreak ?? 0);
  const discount = getDiscountForStreak(streak);

  await db
    .insert(bookingStreaks)
    .values({ memberId, currentStreak: streak, longestStreak: longest, lastBookingDate: today, discountPct: discount })
    .onConflictDoUpdate({
      target: bookingStreaks.memberId,
      set: {
        currentStreak:   streak,
        longestStreak:   longest,
        lastBookingDate: today,
        discountPct:     discount,
        updatedAt:       new Date(),
      },
    });
}
