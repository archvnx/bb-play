export interface StreakTier {
  days:     number;
  discount: number; // %
}

// Скидка применяется при текущем стрике >= days
export const STREAK_TIERS: StreakTier[] = [
  { days: 2,  discount: 1  },
  { days: 3,  discount: 2  },
  { days: 4,  discount: 3  },
  { days: 5,  discount: 4  },
  { days: 7,  discount: 5  },
  { days: 10, discount: 7  },
  { days: 14, discount: 10 },
];

export function getDiscountForStreak(streak: number): number {
  const tier = [...STREAK_TIERS].reverse().find(t => streak >= t.days);
  return tier?.discount ?? 0;
}

export function getNextTier(streak: number): StreakTier | null {
  return STREAK_TIERS.find(t => t.days > streak) ?? null;
}
