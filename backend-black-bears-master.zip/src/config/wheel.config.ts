export type PrizeType = 'free_mins' | 'topup_bonus' | 'booking_discount' | 'nothing';

export interface WheelSector {
  type:   PrizeType;
  value:  number;   // мин / % / 0
  label:  string;
  emoji:  string;
  weight: number;   // относительная вероятность
}

export const WHEEL_CONFIG: WheelSector[] = [
  { type: 'nothing',          value: 0,  label: 'Не повезло',         emoji: '💨', weight: 30 },
  { type: 'free_mins',        value: 5,  label: '+5 мин бесплатно',   emoji: '⏱️', weight: 22 },
  { type: 'free_mins',        value: 10, label: '+10 мин бесплатно',  emoji: '⏱️', weight: 18 },
  { type: 'free_mins',        value: 20, label: '+20 мин бесплатно',  emoji: '🎉', weight: 10 },
  { type: 'topup_bonus',      value: 5,  label: '+5% к пополнению',   emoji: '💰', weight: 10 },
  { type: 'topup_bonus',      value: 10, label: '+10% к пополнению',  emoji: '💰', weight: 5  },
  { type: 'booking_discount', value: 5,  label: 'Скидка 5% на бронь', emoji: '🏷️', weight: 3  },
  { type: 'booking_discount', value: 10, label: 'Скидка 10% на бронь',emoji: '🏷️', weight: 2  },
];

export const TOTAL_WEIGHT = WHEEL_CONFIG.reduce((s, p) => s + p.weight, 0);

export function pickPrize(): WheelSector {
  let rnd = Math.random() * TOTAL_WEIGHT;
  for (const sector of WHEEL_CONFIG) {
    rnd -= sector.weight;
    if (rnd <= 0) return sector;
  }
  return WHEEL_CONFIG[0];
}
