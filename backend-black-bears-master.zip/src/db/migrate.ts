import "dotenv/config";
import { pool } from "./client.js";

const SQL = `
CREATE TABLE IF NOT EXISTS wheel_spins (
  id          SERIAL PRIMARY KEY,
  member_id   VARCHAR(64)  NOT NULL,
  spun_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  prize_type  VARCHAR(32)  NOT NULL,
  prize_value INTEGER      NOT NULL DEFAULT 0,
  promo_code  VARCHAR(20)
);
CREATE INDEX IF NOT EXISTS ws_member_idx ON wheel_spins(member_id);

CREATE TABLE IF NOT EXISTS promo_codes (
  id          SERIAL PRIMARY KEY,
  code        VARCHAR(20)  NOT NULL UNIQUE,
  member_id   VARCHAR(64)  NOT NULL,
  prize_type  VARCHAR(32)  NOT NULL,
  prize_value INTEGER      NOT NULL,
  is_used     BOOLEAN      NOT NULL DEFAULT FALSE,
  used_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  expires_at  TIMESTAMPTZ  NOT NULL
);
CREATE INDEX IF NOT EXISTS pc_member_idx ON promo_codes(member_id);
CREATE INDEX IF NOT EXISTS pc_code_idx   ON promo_codes(code);

CREATE TABLE IF NOT EXISTS booking_streaks (
  member_id          VARCHAR(64) PRIMARY KEY,
  current_streak     INTEGER     NOT NULL DEFAULT 0,
  longest_streak     INTEGER     NOT NULL DEFAULT 0,
  last_booking_date  DATE,
  discount_pct       INTEGER     NOT NULL DEFAULT 0,
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS booking_history (
  id               SERIAL PRIMARY KEY,
  member_id        VARCHAR(64)  NOT NULL,
  member_account   VARCHAR(64),
  icafe_id         VARCHAR(20)  NOT NULL,
  cafe_address     VARCHAR(255),
  pc_name          VARCHAR(30)  NOT NULL,
  zone             VARCHAR(30),
  start_date       VARCHAR(12)  NOT NULL,
  start_time       VARCHAR(10)  NOT NULL,
  duration_mins    INTEGER      NOT NULL,
  cost             DECIMAL(10,2),
  booked_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS bh_member_idx ON booking_history(member_id);

CREATE TABLE IF NOT EXISTS hall_zones (
  id           SERIAL PRIMARY KEY,
  icafe_id     VARCHAR(20) NOT NULL,
  zone_name    VARCHAR(30) NOT NULL,
  x            INTEGER     NOT NULL,
  y            INTEGER     NOT NULL,
  w            INTEGER     NOT NULL,
  h            INTEGER     NOT NULL,
  per_row      INTEGER     NOT NULL DEFAULT 2,
  color_border VARCHAR(50),
  color_fill   VARCHAR(50),
  color_text   VARCHAR(50),
  CONSTRAINT unique_zone_per_cafe UNIQUE(icafe_id, zone_name)
);
CREATE INDEX IF NOT EXISTS hz_icafe_idx ON hall_zones(icafe_id);

INSERT INTO hall_zones (icafe_id, zone_name, x, y, w, h, per_row, color_border, color_fill, color_text)
VALUES
  ('87375', 'BootCamp', 8,   8,   230, 430, 2, '#9333EA', 'rgba(147,51,234,0.13)', '#9333EA'),
  ('87375', 'VIP',      390, 8,   300, 148, 4, '#CA8A04', 'rgba(202,138,4,0.13)',  '#CA8A04'),
  ('87375', 'GameZone', 390, 164, 300, 158, 4, 'transparent', 'rgba(34,197,94,0.11)', '#16A34A'),
  ('87375', 'Касса',   8,   446, 546, 200, 0, '#4B5563', 'rgba(55,65,81,0.3)',   '#4B5563'),
  ('87375', 'Туалет',  562, 446, 130, 200, 0, '#2563EB', 'rgba(30,58,138,0.3)',  '#2563EB')
ON CONFLICT (icafe_id, zone_name) DO UPDATE SET
  x            = EXCLUDED.x,
  y            = EXCLUDED.y,
  w            = EXCLUDED.w,
  h            = EXCLUDED.h,
  per_row      = EXCLUDED.per_row,
  color_border = EXCLUDED.color_border,
  color_fill   = EXCLUDED.color_fill,
  color_text   = EXCLUDED.color_text;
`;

(async () => {
  let client;
  try {
    client = await pool.connect();
    await client.query(SQL);
    console.log("✅ Миграция выполнена успешно");
  } catch (e: any) {
    console.error("❌ Ошибка миграции:", e.message);
    process.exit(1);
  } finally {
    if (client) client.release();
    await pool.end();
    process.exit(0);
  }
})();
