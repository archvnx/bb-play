import {
  pgTable, serial, varchar, integer, timestamp,
  boolean, decimal, date, index,
} from 'drizzle-orm/pg-core';

// ─── Прокрутки колеса ─────────────────────────────────────────────────────────
export const wheelSpins = pgTable('wheel_spins', {
  id:         serial('id').primaryKey(),
  memberId:   varchar('member_id', { length: 64 }).notNull(),
  spunAt:     timestamp('spun_at', { withTimezone: true }).defaultNow().notNull(),
  prizeType:  varchar('prize_type', { length: 32 }).notNull(),
  prizeValue: integer('prize_value').default(0).notNull(),
  promoCode:  varchar('promo_code', { length: 20 }),
}, t => ({ idx: index('ws_member_idx').on(t.memberId) }));

// ─── Промокоды ────────────────────────────────────────────────────────────────
export const promoCodes = pgTable('promo_codes', {
  id:         serial('id').primaryKey(),
  code:       varchar('code', { length: 20 }).notNull().unique(),
  memberId:   varchar('member_id', { length: 64 }).notNull(),
  prizeType:  varchar('prize_type', { length: 32 }).notNull(),
  prizeValue: integer('prize_value').notNull(),
  isUsed:     boolean('is_used').default(false).notNull(),
  usedAt:     timestamp('used_at', { withTimezone: true }),
  createdAt:  timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  expiresAt:  timestamp('expires_at', { withTimezone: true }).notNull(),
}, t => ({
  memberIdx: index('pc_member_idx').on(t.memberId),
  codeIdx:   index('pc_code_idx').on(t.code),
}));

// ─── Стрики ───────────────────────────────────────────────────────────────────
export const bookingStreaks = pgTable('booking_streaks', {
  memberId:        varchar('member_id', { length: 64 }).primaryKey(),
  currentStreak:   integer('current_streak').default(0).notNull(),
  longestStreak:   integer('longest_streak').default(0).notNull(),
  lastBookingDate: date('last_booking_date'),
  discountPct:     integer('discount_pct').default(0).notNull(),
  updatedAt:       timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});

// ─── История бронирований ─────────────────────────────────────────────────────
export const bookingHistory = pgTable('booking_history', {
  id:              serial('id').primaryKey(),
  memberId:        varchar('member_id', { length: 64 }).notNull(),
  memberAccount:   varchar('member_account', { length: 64 }),
  icafeId:         varchar('icafe_id', { length: 20 }).notNull(),
  cafeAddress:     varchar('cafe_address', { length: 255 }),
  pcName:          varchar('pc_name', { length: 30 }).notNull(),
  zone:            varchar('zone', { length: 30 }),
  startDate:       varchar('start_date', { length: 12 }).notNull(),
  startTime:       varchar('start_time', { length: 10 }).notNull(),
  durationMins:    integer('duration_mins').notNull(),
  cost:            decimal('cost', { precision: 10, scale: 2 }),
  bookedAt:        timestamp('booked_at', { withTimezone: true }).defaultNow().notNull(),
}, t => ({ idx: index('bh_member_idx').on(t.memberId) }));

// ─── Зоны залов ───────────────────────────────────────────────────────────────
export const hallZones = pgTable('hall_zones', {
  id:          serial('id').primaryKey(),
  icafeId:     varchar('icafe_id', { length: 20 }).notNull(),
  zoneName:    varchar('zone_name', { length: 30 }).notNull(),
  x:           integer('x').notNull(),
  y:           integer('y').notNull(),
  w:           integer('w').notNull(),
  h:           integer('h').notNull(),
  perRow:      integer('per_row').default(2).notNull(),
  colorBorder: varchar('color_border', { length: 50 }),
  colorFill:   varchar('color_fill', { length: 50 }),
  colorText:   varchar('color_text', { length: 50 }),
}, t => ({ idx: index('hz_icafe_idx').on(t.icafeId) }));
