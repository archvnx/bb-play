import { pool } from './db/client.js';

async function runCleanup() {
  const client = await pool.connect();
  try {
    const r1 = await client.query(`
      DELETE FROM booking_history
      WHERE booked_at < NOW() - INTERVAL '90 days'
    `);
    if (r1.rowCount) console.log(`[cleanup] booking_history: удалено ${r1.rowCount} строк`);

    const r2 = await client.query(`
      DELETE FROM promo_codes
      WHERE expires_at < NOW()
    `);
    if (r2.rowCount) console.log(`[cleanup] promo_codes: удалено ${r2.rowCount} строк`);

    const r3 = await client.query(`
      DELETE FROM wheel_spins
      WHERE spun_at < NOW() - INTERVAL '30 days'
    `);
    if (r3.rowCount) console.log(`[cleanup] wheel_spins: удалено ${r3.rowCount} строк`);

    await client.query('VACUUM ANALYZE booking_history, promo_codes, wheel_spins');
    console.log('[cleanup] VACUUM ANALYZE выполнен');
  } catch (e: any) {
    console.error('[cleanup] ошибка:', e.message);
  } finally {
    client.release();
  }
}

runCleanup();
setInterval(runCleanup, 24 * 60 * 60 * 1000);
