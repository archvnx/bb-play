import 'dotenv/config';
import cors from 'cors';
import express from 'express';
import axios from 'axios';

import { wheelRouter }   from './modules/wheel/wheel.router.js';
import { streakRouter }  from './modules/streak/streak.router.js';
import { promoRouter }   from './modules/promo/promo.router.js';
import { historyRouter } from './modules/history/history.router.js';
import { zonesRouter }   from './modules/zones/zones.router.js';import './cleanup.js';

const app  = express();
const PORT = process.env.PORT || 3000;

// Уменьшили лимит с 5mb до 1mb для безопасности
app.use(express.json({ limit: '1mb' }));
app.use(cors());

// ─── Наши модули ──────────────────────────────────────────────────────────────
app.use('/wheel',   wheelRouter);
app.use('/streak',  streakRouter);
app.use('/promo',   promoRouter);
app.use('/history', historyRouter);
app.use('/zones',   zonesRouter);

// ─── Логика кэширования VK ────────────────────────────────────────────────────
let cachedNews: any[] | null = null;
let lastNewsFetch = 0;
const CACHE_TTL = 10 * 60 * 1000; // 10 минут в миллисекундах

app.get('/news', async (req, res) => {
  const now = Date.now();
  
  // Если есть кэш и он не протух — отдаем его
  if (cachedNews && (now - lastNewsFetch < CACHE_TTL)) {
    return res.json(cachedNews);
  }

  try {
    const response = await axios.get('https://api.vk.com/method/wall.get', {
      params: {
        owner_id:     process.env.VK_GROUP_ID,
        count:        20,
        access_token: process.env.VK_ACCESS_TOKEN,
        v:            process.env.VK_API_VERSION || '5.131',
      },
    });

    if (response.data.error) {
      console.error('[VK API Error]:', response.data.error.error_msg);
      return res.status(500).json({ error: 'Ошибка VK API' });
    }

    const items = response.data.response.items || [];
    const news = items.map((post: any) => {
      const postData = post.copy_history?.[0] || post;
      const text = postData.text || '';
      const attachments = postData.attachments || [];
      
      const images = attachments
        .filter((a: any) => a.type === 'photo')
        .map((a: any) => a.photo?.sizes?.sort((s1: any, s2: any) => s2.width - s1.width)[0]?.url)
        .filter(Boolean);

      const pollData = attachments.find((a: any) => a.type === 'poll')?.poll;

      return {
        id: post.id,
        text,
        date: post.date,
        images,
        poll: pollData ? {
          question: pollData.question,
          answers: pollData.answers.map((a: any) => ({ text: a.text, rate: a.rate || 0 })),
        } : null,
      };
    }).filter((p: any) => p.text || p.images?.length > 0 || p.poll);

    // Обновляем кэш
    cachedNews = news;
    lastNewsFetch = now;

    return res.json(news);
  } catch (e: any) {
    console.error('[News error]:', e.message);
    // Если VK упал, но в кэше что-то есть — отдаем старые данные
    return cachedNews ? res.json(cachedNews) : res.status(500).json([]);
  }
});

// ─── Чат-бот ──────────────────────────────────────────────────
const SYSTEM_PROMPT = `Ты — умный помощник мобильного приложения сети компьютерных клубов BlackBears Play (Тамбов).
Твоя задача — помогать пользователям разобраться в приложении и ответить на вопросы о клубе.
Отвечай только на вопросы, связанные с клубом и приложением. Будь кратким, дружелюбным и конкретным.
Если вопрос не по теме — вежливо скажи, что можешь помочь только по BlackBears Play.

Название: BlackBears Play | Город: Тамбов | Адрес: Медвежья д.1 | ВКонтакте: vk.com/bbplay__tmb

Функции приложения: бронирование ПК (BootCamp/GameZone/VIP), баланс/бонусы, новости, чат-бот,
колесо фортуны (раз в сутки), стрик-скидки (бронируй каждый день — скидка растёт до 10%),
промокоды (виртуальные, для получения приза обратись к администратору клуба).`;

app.post('/chat', async (req, res) => {
  const { messages } = req.body;
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'messages required' });
  }
  
  if (!process.env.GROQ_API_KEY) {
    return res.status(500).json({ error: 'Конфигурация чат-бота не завершена' });
  }

  try {
    const response = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        model:      'llama-3.1-8b-instant',
        max_tokens: 512,
        messages:   [{ role: 'system', content: SYSTEM_PROMPT }, ...messages],
      },
      { 
        headers: { 
          'Authorization': `Bearer ${process.env.GROQ_API_KEY}`, 
          'Content-Type': 'application/json' 
        },
        timeout: 10000 // Таймаут 10 секунд, чтобы запрос не висел вечно
      },
    );
    return res.json({ role: 'assistant', content: response.data.choices[0].message.content });
  } catch (e: any) {
    console.error('[Groq error]:', e.response?.data?.error?.message || e.message);
    return res.status(500).json({ error: 'Ошибка нейросети. Попробуйте позже.' });
  }
});

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ ok: true, ts: new Date().toISOString() }));

app.listen(PORT, () => console.log(`🚀 Сервер запущен на порту ${PORT}`));
// ─── Диагностика БД ───────────────────────────────────────────────────────────
import { pool } from './db/client.js';

app.get('/db-stats', async (_req, res) => {
  const client = await pool.connect();
  try {
    const sizes = await client.query(`
      SELECT
        relname AS "table",
        pg_size_pretty(pg_total_relation_size(oid)) AS "total",
        pg_size_pretty(pg_relation_size(oid)) AS "data",
        pg_size_pretty(pg_total_relation_size(oid) - pg_relation_size(oid)) AS "indexes"
      FROM pg_class
      WHERE relkind = 'r' AND relname NOT LIKE 'pg_%'
      ORDER BY pg_total_relation_size(oid) DESC
      LIMIT 20
    `);

    const bloat = await client.query(`
      SELECT
        relname AS "table",
        n_live_tup AS "live_rows",
        n_dead_tup AS "dead_rows",
        COALESCE(last_autovacuum::text, 'никогда') AS "last_autovacuum",
        COALESCE(last_autoanalyze::text, 'никогда') AS "last_autoanalyze"
      FROM pg_stat_user_tables
      ORDER BY n_dead_tup DESC
    `);

    const dbSize = await client.query(`
      SELECT pg_size_pretty(pg_database_size(current_database())) AS "db_size"
    `);

    res.json({
      db_size: dbSize.rows[0].db_size,
      tables:  sizes.rows,
      bloat:   bloat.rows,
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});
