/** 'YYYY-MM-DD' сегодня в UTC */
export function todayDateStr(): string {
  return new Date().toISOString().slice(0, 10);
}

/** 'YYYY-MM-DD' вчера в UTC */
export function yesterdayDateStr(): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - 1);
  return d.toISOString().slice(0, 10);
}

/** Начало сегодняшнего дня UTC (для сравнения timestamp) */
export function todayUTCStart(): Date {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  return d;
}

/** Начало следующего дня UTC */
export function tomorrowUTCStart(): Date {
  const d = todayUTCStart();
  d.setUTCDate(d.getUTCDate() + 1);
  return d;
}
