import { db } from '../db/client.js';
import { promoCodes } from '../db/schema.js';
import { eq } from 'drizzle-orm';

const CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function segment(n: number): string {
  return Array.from({ length: n }, () => CHARS[Math.floor(Math.random() * CHARS.length)]).join('');
}

/** Генерирует уникальный промокод BEAR-XXXX-XXXX с проверкой в БД */
export async function generateUniqueCode(): Promise<string | null> {
  for (let attempt = 0; attempt < 5; attempt++) {
    const candidate = `BEAR-${segment(4)}-${segment(4)}`;
    const dupe = await db
      .select({ code: promoCodes.code })
      .from(promoCodes)
      .where(eq(promoCodes.code, candidate))
      .limit(1);
    if (dupe.length === 0) return candidate;
  }
  return null; // крайне маловероятно
}

/** Дата истечения: сейчас + N дней */
export function expiresInDays(days: number): Date {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d;
}
