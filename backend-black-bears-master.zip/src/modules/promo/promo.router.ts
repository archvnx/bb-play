import { Router, Request, Response } from 'express';
import { getMyPromoCodes, markCodeUsed, validateCode } from './promo.service.js';

export const promoRouter = Router();

promoRouter.get('/my', async (req: Request, res: Response) => {
  const { member_id } = req.query as { member_id?: string };
  if (!member_id) return res.status(400).json({ error: 'member_id required' });
  try {
    return res.json(await getMyPromoCodes(member_id));
  } catch (e: any) {
    console.error('[promo/my]', e.message);
    return res.status(500).json({ error: 'Ошибка сервера' });
  }
});

promoRouter.post('/validate', async (req: Request, res: Response) => {
  const { code, member_id } = req.body as { code?: string; member_id?: string };
  if (!code || !member_id) return res.status(400).json({ error: 'code и member_id обязательны' });
  try {
    return res.json(await validateCode(code, member_id));
  } catch (e: any) {
    return res.status(e.statusCode ?? 500).json({ error: e.message });
  }
});

promoRouter.post('/use', async (req: Request, res: Response) => {
  const { code, member_id } = req.body as { code?: string; member_id?: string };
  if (!code || !member_id) return res.status(400).json({ error: 'code и member_id обязательны' });
  try {
    return res.json(await markCodeUsed(code, member_id));
  } catch (e: any) {
    return res.status(e.statusCode ?? 500).json({ error: e.message });
  }
});
