import { and, eq } from 'drizzle-orm';
import { db } from '../../db/client.js';
import { promoCodes } from '../../db/schema.js';

const PRIZE_LABEL: Record<string, string> = {
  free_mins:        'Бесплатные минуты',
  topup_bonus:      'Бонус к пополнению',
  booking_discount: 'Скидка на бронирование',
};
const PRIZE_UNIT: Record<string, string> = {
  free_mins:        'мин',
  topup_bonus:      '%',
  booking_discount: '%',
};

/** NOTE: промокоды виртуальные — показываются в профиле, но не применяются
 *  автоматически при бронировании через iCafeCloud.
 *  Для free_mins и topup_bonus нужно обратиться к администратору.
 *  booking_discount пока только информационный.
 */
export async function getMyPromoCodes(memberId: string) {
  const now  = new Date();
  const rows = await db
    .select()
    .from(promoCodes)
    .where(and(eq(promoCodes.memberId, memberId), eq(promoCodes.isUsed, false)));

  return rows
    .filter(c => new Date(c.expiresAt) > now)
    .map(c => ({
      id:         c.id,
      code:       c.code,
      prizeType:  c.prizeType,
      prizeValue: c.prizeValue,
      prizeLabel: PRIZE_LABEL[c.prizeType] ?? c.prizeType,
      prizeUnit:  PRIZE_UNIT[c.prizeType]  ?? '',
      expiresAt:  c.expiresAt,
      createdAt:  c.createdAt,
    }));
}

export async function validateCode(code: string, memberId: string) {
  const rows = await db
    .select()
    .from(promoCodes)
    .where(and(eq(promoCodes.code, code.toUpperCase()), eq(promoCodes.memberId, memberId)))
    .limit(1);

  if (!rows.length)                              throw clientError(404, 'Промокод не найден');
  if (rows[0].isUsed)                            throw clientError(400, 'Промокод уже использован');
  if (new Date(rows[0].expiresAt) < new Date())  throw clientError(400, 'Промокод истёк');

  const c = rows[0];
  return {
    valid:      true,
    prizeType:  c.prizeType,
    prizeValue: c.prizeValue,
    prizeLabel: PRIZE_LABEL[c.prizeType] ?? c.prizeType,
    prizeUnit:  PRIZE_UNIT[c.prizeType]  ?? '',
  };
}

export async function markCodeUsed(code: string, memberId: string) {
  const rows = await db
    .select()
    .from(promoCodes)
    .where(and(eq(promoCodes.code, code.toUpperCase()), eq(promoCodes.memberId, memberId)))
    .limit(1);

  if (!rows.length)       throw clientError(404, 'Промокод не найден');
  if (rows[0].isUsed)     throw clientError(400, 'Уже использован');
  if (new Date(rows[0].expiresAt) < new Date()) throw clientError(400, 'Истёк');

  await db
    .update(promoCodes)
    .set({ isUsed: true, usedAt: new Date() })
    .where(eq(promoCodes.code, code.toUpperCase()));

  return { success: true, prizeType: rows[0].prizeType, prizeValue: rows[0].prizeValue };
}

function clientError(status: number, message: string) {
  const e = new Error(message) as any;
  e.statusCode = status;
  return e;
}
