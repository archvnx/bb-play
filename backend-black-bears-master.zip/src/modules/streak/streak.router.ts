import { Router, Request, Response } from 'express';
import { getStreak } from './streak.service.js';

export const streakRouter = Router();

streakRouter.get('/', async (req: Request, res: Response) => {
  const { member_id } = req.query as { member_id?: string };
  if (!member_id) return res.status(400).json({ error: 'member_id required' });
  try {
    return res.json(await getStreak(member_id));
  } catch (e: any) {
    console.error('[streak]', e.message);
    return res.status(500).json({ error: 'Ошибка сервера' });
  }
});
