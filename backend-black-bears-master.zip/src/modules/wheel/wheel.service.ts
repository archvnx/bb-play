import { and, eq, gte } from 'drizzle-orm';
import { WHEEL_CONFIG, pickPrize } from '../../config/wheel.config.js';
import { db } from '../../db/client.js';
import { promoCodes, wheelSpins } from '../../db/schema.js';
import { todayUTCStart, tomorrowUTCStart } from '../../utils/date.js';
import { expiresInDays, generateUniqueCode } from '../../utils/promoCode.js';

export interface SpinStatus {
  canSpin:     boolean;
  nextSpinAt:  string | null;  // ISO
  lastPrize:   { type: string; value: number; code: string | null } | null;
  sectors:     { label: string; emoji: string; type: string; value: number }[];
}

export interface SpinResult {
  prizeType:   string;
  prizeValue:  number;
  prizeLabel:  string;
  prizeEmoji:  string;
  promoCode:   string | null;
  sectorIndex: number;
}

export async function getSpinStatus(memberId: string): Promise<SpinStatus> {
  const todayStart = todayUTCStart();

  const todaySpin = await db
    .select()
    .from(wheelSpins)
    .where(and(eq(wheelSpins.memberId, memberId), gte(wheelSpins.spunAt, todayStart)))
    .limit(1);

  const canSpin  = todaySpin.length === 0;
  const lastSpin = todaySpin[0] ?? null;

  return {
    canSpin,
    nextSpinAt: canSpin ? null : tomorrowUTCStart().toISOString(),
    lastPrize:  lastSpin
      ? { type: lastSpin.prizeType, value: lastSpin.prizeValue, code: lastSpin.promoCode ?? null }
      : null,
    sectors: WHEEL_CONFIG.map(s => ({ label: s.label, emoji: s.emoji, type: s.type, value: s.value })),
  };
}

export async function doSpin(memberId: string): Promise<SpinResult> {
  // Проверяем что сегодня ещё не крутили
  const todayStart  = todayUTCStart();
  const existing    = await db
    .select({ id: wheelSpins.id })
    .from(wheelSpins)
    .where(and(eq(wheelSpins.memberId, memberId), gte(wheelSpins.spunAt, todayStart)))
    .limit(1);

  if (existing.length > 0) {
    const err = new Error('already_spun') as any;
    err.statusCode = 400;
    err.clientMessage = 'Сегодня уже крутили! Приходи завтра 🎰';
    throw err;
  }

  const prize = pickPrize();

  // Генерируем промокод для реальных призов
  let promoCode: string | null = null;
  if (prize.type !== 'nothing') {
    promoCode = await generateUniqueCode();
    if (promoCode) {
      await db.insert(promoCodes).values({
        code:       promoCode,
        memberId,
        prizeType:  prize.type,
        prizeValue: prize.value,
        expiresAt:  expiresInDays(7),
      });
    }
  }

  await db.insert(wheelSpins).values({
    memberId,
    prizeType:  prize.type,
    prizeValue: prize.value,
    promoCode,
  });

  return {
    prizeType:   prize.type,
    prizeValue:  prize.value,
    prizeLabel:  prize.label,
    prizeEmoji:  prize.emoji,
    promoCode,
    sectorIndex: WHEEL_CONFIG.findIndex(s => s.type === prize.type && s.value === prize.value),
  };
}
