import { Router, Request, Response } from 'express';
import { doSpin, getSpinStatus } from './wheel.service.js';

export const wheelRouter = Router();

wheelRouter.get('/status', async (req: Request, res: Response) => {
  const { member_id } = req.query as { member_id?: string };
  if (!member_id) return res.status(400).json({ error: 'member_id required' });
  try {
    const status = await getSpinStatus(member_id);
    return res.json(status);
  } catch (e: any) {
    console.error('[wheel/status]', e.message);
    return res.status(500).json({ error: 'Ошибка сервера' });
  }
});

wheelRouter.post('/spin', async (req: Request, res: Response) => {
  const { member_id } = req.body as { member_id?: string };
  if (!member_id) return res.status(400).json({ error: 'member_id required' });
  try {
    const result = await doSpin(member_id);
    return res.json(result);
  } catch (e: any) {
    if (e.statusCode === 400) return res.status(400).json({ error: e.message, message: e.clientMessage });
    console.error('[wheel/spin]', e.message);
    return res.status(500).json({ error: 'Ошибка сервера' });
  }
});
