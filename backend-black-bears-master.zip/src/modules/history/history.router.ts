import { Router, Request, Response } from 'express';
import { getHistory, getStats, saveBooking } from './history.service.js';

export const historyRouter = Router();

historyRouter.post('/', async (req: Request, res: Response) => {
  const { member_id, member_account, icafe_id, cafe_address,
          pc_name, start_date, start_time, duration_mins, cost } = req.body;

  if (!member_id || !icafe_id || !pc_name || !start_date || !start_time || !duration_mins) {
    return res.status(400).json({ error: 'Недостаточно данных' });
  }
  try {
    await saveBooking({
      memberId:      String(member_id),
      memberAccount: member_account,
      icafeId:       String(icafe_id),
      cafeAddress:   cafe_address,
      pcName:        pc_name,
      startDate:     start_date,
      startTime:     start_time,
      durationMins:  Number(duration_mins),
      cost:          cost != null ? Number(cost) : undefined,
    });
    return res.json({ success: true });
  } catch (e: any) {
    console.error('[history POST]', e.message);
    return res.status(500).json({ error: 'Ошибка сохранения' });
  }
});

historyRouter.get('/:memberId', async (req: Request, res: Response) => {
  const { memberId } = req.params;
  const page  = Math.max(1, Number(req.query.page)  || 1);
  const limit = Math.min(50, Number(req.query.limit) || 20);
  try {
    return res.json(await getHistory(memberId, page, limit));
  } catch (e: any) {
    console.error('[history GET]', e.message);
    return res.status(500).json({ error: 'Ошибка сервера' });
  }
});

historyRouter.get('/:memberId/stats', async (req: Request, res: Response) => {
  try {
    return res.json(await getStats(req.params.memberId));
  } catch (e: any) {
    console.error('[history/stats]', e.message);
    return res.status(500).json({ error: 'Ошибка сервера' });
  }
});
