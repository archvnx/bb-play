import { desc, eq, sql } from 'drizzle-orm';
import { db } from '../../db/client.js';
import { bookingHistory } from '../../db/schema.js';
import { updateStreak } from '../streak/streak.service.js';

function detectZone(pcName: string): string {
  const n = pcName.toUpperCase();
  if (n.startsWith('BC'))                    return 'BootCamp';
  if (n.startsWith('VP') || n.startsWith('VIP')) return 'VIP';
  return 'GameZone';
}

export interface SaveBookingDto {
  memberId:        string;
  memberAccount?:  string;
  icafeId:         string;
  cafeAddress?:    string;
  pcName:          string;
  startDate:       string;
  startTime:       string;
  durationMins:    number;
  cost?:           number;
}

/** Сохраняет бронь и автоматически обновляет стрик */
export async function saveBooking(dto: SaveBookingDto): Promise<void> {
  await db.insert(bookingHistory).values({
    memberId:      dto.memberId,
    memberAccount: dto.memberAccount ?? null,
    icafeId:       dto.icafeId,
    cafeAddress:   dto.cafeAddress ?? null,
    pcName:        dto.pcName,
    zone:          detectZone(dto.pcName),
    startDate:     dto.startDate,
    startTime:     dto.startTime,
    durationMins:  dto.durationMins,
    cost:          dto.cost != null ? String(dto.cost) : null,
  });

  // Обновляем стрик после записи — fire-and-forget, не блокируем ответ
  updateStreak(dto.memberId).catch(e => console.error('[history] updateStreak:', e.message));
}

export async function getHistory(memberId: string, page: number, limit: number) {
  return db
    .select()
    .from(bookingHistory)
    .where(eq(bookingHistory.memberId, memberId))
    .orderBy(desc(bookingHistory.bookedAt))
    .limit(limit)
    .offset((page - 1) * limit);
}

export async function getStats(memberId: string) {
  const result = await db.execute(sql`
    SELECT
      COUNT(*)::int                             AS total_bookings,
      COALESCE(SUM(duration_mins), 0)::int      AS total_mins,
      COALESCE(SUM(cost::numeric), 0)::numeric  AS total_spent,
      (SELECT zone FROM booking_history
       WHERE member_id = ${memberId}
       GROUP BY zone ORDER BY COUNT(*) DESC LIMIT 1) AS favorite_zone,
      (SELECT pc_name FROM booking_history
       WHERE member_id = ${memberId}
       GROUP BY pc_name ORDER BY COUNT(*) DESC LIMIT 1) AS favorite_pc,
      (SELECT COUNT(*)::int FROM booking_history
       WHERE member_id = ${memberId}
         AND booked_at >= date_trunc('month', NOW())) AS bookings_this_month,
      MIN(booked_at) AS member_since
    FROM booking_history
    WHERE member_id = ${memberId}
  `);

  const r = result.rows[0] ?? {};
  return {
    totalBookings:      r.total_bookings      ?? 0,
    totalHours:         (((r.total_mins as number) ?? 0) / 60).toFixed(1),
    totalSpent:         Number(r.total_spent  ?? 0).toFixed(2),
    favoriteZone:       r.favorite_zone       ?? '',
    favoritePc:         r.favorite_pc         ?? '',
    bookingsThisMonth:  r.bookings_this_month ?? 0,
    memberSince:        r.member_since        ?? null,
  };
}
