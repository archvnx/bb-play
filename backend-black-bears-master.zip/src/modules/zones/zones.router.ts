import { Router, Request, Response } from 'express';
import { eq } from 'drizzle-orm';
import { db } from '../../db/client.js';
import { hallZones } from '../../db/schema.js';

export const zonesRouter = Router();

/**
 * GET /zones/:icafeId
 * Возвращает координаты и цвета зон зала.
 * Позиции компьютеров приходят через старый прокси (iCafeCloud) — не трогаем.
 */
zonesRouter.get('/:icafeId', async (req: Request, res: Response) => {
  const { icafeId } = req.params;
  try {
    const rows = await db
      .select()
      .from(hallZones)
      .where(eq(hallZones.icafeId, icafeId));

    return res.json(
      rows.map(z => ({
        zoneName:    z.zoneName,
        x:           z.x,
        y:           z.y,
        w:           z.w,
        h:           z.h,
        perRow:      z.perRow,
        colorBorder: z.colorBorder,
        colorFill:   z.colorFill,
        colorText:   z.colorText,
      }))
    );
  } catch (e: any) {
    console.error('[zones]', e.message);
    return res.status(500).json({ error: 'Ошибка сервера' });
  }
});
